<div class="guarantee-box-4 guarantee-box-4-silver ">
	<div class="guarantee-box-4-internal">
		<img alt="" src="<?php echo OP_ASSETS_URL ?>images/guarantee_box/money-back-logo.png" />
		<div class="guarantee-content">
			<h2<?php echo $title_style ?>><?php echo $title ?></h2>
			<?php echo $content ?>
		</div>
	</div>
</div>