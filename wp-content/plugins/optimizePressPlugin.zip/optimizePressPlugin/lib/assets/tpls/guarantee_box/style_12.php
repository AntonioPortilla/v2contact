<div class="guarantee-box-12 guarantee-box-12-orange">
	<img class="guarantee-box-12-header" src="<?php echo OP_ASSETS_URL ?>images/guarantee_box/style-5-top-orange.png" alt="style-5-top-orange" width="552" height="87" />
	<div class="guarantee-box-internal">
		<h2<?php echo $title_style ?>><?php echo $title ?></h2>
		<?php echo $content ?>
	</div>
	<img class="guarantee-box-12-footer" src="<?php echo OP_ASSETS_URL ?>images/guarantee_box/style-5-bottom.png" alt="style-5-bottom" width="552" height="63" />
</div>