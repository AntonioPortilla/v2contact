<div class="styled-hr hr-style-1">
    <div class="ornament">
        <img src="<?php echo $path; ?>shadow-ornament.png" alt="shadow-ornament" width="81" height="40" />
    </div>
    <div class="hr-1"></div>
    <div class="hr-2">
        <hr />
    </div>
</div>