<div class="styled-hr hr-style-2">
	<img src="<?php echo $path; ?>ornament-2.png" alt="shadow-ornament" width="32" height="39" class="ornament" />
	<hr />
</div>