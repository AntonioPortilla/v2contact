<div class="styled-hr hr-style-5">
    <a href="#">
        <?php echo $label; ?>
    </a>
    <hr />
</div>