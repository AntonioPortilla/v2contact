<div class="styled-hr hr-style-6">
    <hr />
</div>