<?php echo $this->load_tpl('header', array('title' => 'Hub')) ?>
<?php echo $this->load_tpl('footer') ?>