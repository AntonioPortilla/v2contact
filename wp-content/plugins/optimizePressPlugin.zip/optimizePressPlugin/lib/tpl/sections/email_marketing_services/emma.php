<div class="op-bsw-grey-panel-content op-bsw-grey-panel-no-sidebar cf">
    <label for="op_sections_email_marketing_services_emma_account_id" class="form-title"><?php _e('Account ID', OP_SN); ?></label>
    <?php op_text_field('op[sections][email_marketing_services][emma_account_id]', op_get_option('emma_account_id')); ?>
    <label for="op_sections_email_marketing_services_emma_public_key" class="form-title"><?php _e('Public API Key', OP_SN); ?></label>
    <?php op_text_field('op[sections][email_marketing_services][emma_public_key]', op_get_option('emma_public_key')); ?>
    <label for="op_sections_email_marketing_services_emma_private_key" class="form-title"><?php _e('Private API Key', OP_SN); ?></label>
    <?php op_text_field('op[sections][email_marketing_services][emma_private_key]', op_get_option('emma_private_key')); ?>
</div>