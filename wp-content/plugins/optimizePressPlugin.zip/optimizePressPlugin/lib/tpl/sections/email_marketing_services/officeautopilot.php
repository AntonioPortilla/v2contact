<div class="op-bsw-grey-panel-content op-bsw-grey-panel-no-sidebar cf">        
    <label for="op_sections_email_marketing_services_officeautopilot_app_id" class="form-title"><?php _e('OfficeAutopilot App ID', OP_SN); ?></label>
    <?php op_text_field('op[sections][email_marketing_services][officeautopilot_app_id]', op_get_option('officeautopilot_app_id')); ?>
    <label for="op_sections_email_marketing_services_officeautopilot_api_key" class="form-title"><?php _e('OfficeAutopilot API Key', OP_SN); ?></label>
    <?php op_text_field('op[sections][email_marketing_services][officeautopilot_api_key]', op_get_option('officeautopilot_api_key')); ?>
</div>