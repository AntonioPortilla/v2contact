<div class="op-bsw-grey-panel-content op-bsw-grey-panel-no-sidebar cf">        
    <label for="op_sections_email_marketing_services_mailchimp_api_key" class="form-title"><?php _e('MailChimp API key', OP_SN); ?></label>
    <p class="op-micro-copy"><?php _e('Copy MailChimp API key here.', OP_SN); ?></p>
    <?php op_text_field('op[sections][email_marketing_services][mailchimp_api_key]', op_get_option('mailchimp_api_key')); ?>
</div>