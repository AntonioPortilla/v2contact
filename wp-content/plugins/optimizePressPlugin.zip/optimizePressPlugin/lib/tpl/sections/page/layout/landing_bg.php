<div class="op-bsw-grey-panel-content op-bsw-grey-panel-no-sidebar cf" id="op_page_layout_landing_bg">
    <label for="op_header_layout_logo" class="form-title"><?php _e('Background Image',OP_SN) ?></label>
    <p class="op-micro-copy"><?php _e('Upload a image to use as the background for your page.',OP_SN) ?></p>
    <?php op_upload_field('op[landing_bg][image]',op_default_page_option('landing_bg','image')) ?>
</div>