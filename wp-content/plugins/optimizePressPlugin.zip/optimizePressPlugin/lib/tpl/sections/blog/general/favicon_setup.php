<div class="op-bsw-grey-panel-content op-bsw-grey-panel-no-sidebar cf">
    <label for="op_favicon" class="form-title"><?php _e('Upload your favicon',OP_SN) ?></label>
    <p class="op-micro-copy"><?php _e('Favicons should be 16px by 16px.',OP_SN) ?></p>
    <?php op_upload_field('op[sections][favicon_setup]',op_default_option('favicon_setup')) ?>
    <div class="clear"></div>
</div>