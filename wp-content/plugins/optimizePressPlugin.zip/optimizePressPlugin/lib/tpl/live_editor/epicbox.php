<div id="epicbox-overlay" class="op-hidden"></div>
<div id="epicbox" class="op-hidden">
	<a href="#" class="close"></a>
	<div class="epicbox-content">
		<form action="#" method="post" id="op_child_elements_form" novalidate>
			<div class="epicbox-scroll">

			</div>
		</form>
	</div>
</div>