<?php echo $this->load_tpl('wizard/header') ?>
<h1><?php _e('Your blog has been successfully setup!',OP_SN) ?></h1>
<!--<div class="form-actions">
	<div class="form-actions-content cf">
		<a href="<?php menu_page_url(OP_SN) ?>" class="op-pb-button green">Continue to Blog Settings</a>
	</div>
</div>-->
<?php // echo $this->load_tpl('wizard/footer',array('hide_submit'=>true)) ?>
<?php echo $this->load_tpl('wizard/footer') ?>