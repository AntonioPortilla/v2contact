<div class="postbox" id="op-post-<?php echo $id ?>">
	<div title="Click to toggle" class="handlediv"><br></div>
    <h3 class="hndle"><span><?php echo $title ?></span></h3>
    <div class="inside">
    	<?php echo $content ?>
    </div>
</div>