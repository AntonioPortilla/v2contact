<?php
	define('APP_DOMAIN', 'http://www.v2contact.com');
	define('APP_PUBLIC', APP_DOMAIN . '/wp-content/themes/zenite');
	define('ASSETS_PATH', APP_PUBLIC . '/assets');
?>