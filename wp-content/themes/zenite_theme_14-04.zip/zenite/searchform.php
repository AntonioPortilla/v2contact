<form action="<?php echo home_url(); ?>" method="get">
    <fieldset>
		<input id="s" name="s" type="text" value="Buscar"  />
    </fieldset>
</form>

