# mb.menu

__An open source jQuery component to easily build a tree menu.__

![mb.menu](http://pupunzi.com/gitHub/mb.menu.jpg)

## [go to the demo](http://pupunzi.com/#mb.components/mb._menu/menu.html)
## [go to the Doc](http://wiki.github.com/pupunzi/jquery.mb.menu/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web