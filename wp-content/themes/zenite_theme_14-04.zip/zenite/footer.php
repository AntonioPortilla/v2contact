﻿<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after.  Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Starkers
 * @since Starkers 3.0
 */
?>
<?php global $NHP_Options; 

 if(isset($_POST['submitted2'])) {
  if(trim($_POST['email']) === '')  {
    $emailError = 'Please enter your email address.';
    $hasError = true;
  } else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
    $emailError = 'You entered an invalid email address.';
    $hasError = true;
  } else {
    $email = trim($_POST['email']);
  }

  if(!isset($hasError)) {
    $emailTo = $NHP_Options->get('subscribe_email');
    if (!isset($emailTo) || ($emailTo == '') ){
      $emailTo = get_option('admin_email');
    }
    
    //$emailTo ='albert.canals@medusateam.com';
    
    $subject = 'New email submited';
    $body = "New email submited from call us\n\nEmail: $email ";
    $headers = 'From: '.$name.' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;

    wp_mail($emailTo, $subject, $body, $headers);
    $emailSent2 = true;
  }
}
?>
<div class="wrapper_call clearfix" style="display: none;">
      <!--<div class="separa_big"></div>-->       
</div>
<div class="wrapper_footer" style="float: left;position: initial;">
  <div class="detall" style="display: none;"></div>
  <div class="bgtwitter" style="display: none;"></div>
  <footer class="container clearfix" style=" min-height:250px;">
    <div class="contentSF1">
      <div id="subfooter1">
        <?php
          /* A sidebar in the footer? Yep. You can can customize
           * your footer with four columns of widgets.
          */  
           get_sidebar( 'footer' );
        ?>
      </div>
      
      <div class="SMleftDown" style="background: silver;">
        <ul style="float: left; margin-top: 50px;">
          <li style="margin-left: -15px;border-left: initial;"><span class="linea"></span><a href="" class="ASMdown1">Aviso legal</a></li>
          <li style="border: initial;"><a href="" class="ASMdown2">Condiciones de Uso</a></li>
          <li><a href="" class="ASMdown3">Cookies</a></li>
          <li style="border: initial;"><a href="" class="ASMdown4">Politica de Calidad</a></li>
          <li style="border-right: 0px;"><a href="" class="ASMdown5">Política de Seguridad</a></li>
        </ul>
      </div> 
    </div>
    <div id="subfooter_blank" style="width: 5%;height: 1px;float: left;"></div>
    <div class="contentSF2">      
      <div id="subfooter2">
        <span>
          <div>
            <span class="span1">V2Contact LLC</span> <br>
            Calle dos de Mayo 516 Oficina 201 <br>
            Miraflores Lima Perú <br>
            Teléfono: 708-4100 <br><br>
            <label>Soporte Técnico</label>
            Mediante chats y tickets dentro del panel
          </div>
        </span>
      </div>
      <div class="SMrightDown" style="background: silver;">
        <div style="float: left; margin-top: 15px;">
          <div class="icones">
            <span class="copy_right" style="display: block;"><span class="social seguiendo">siguenos:</span></span><br>
                <?php if($NHP_Options->get('tumblr')!=''){?><a href="<?php $NHP_Options->show('tumblr'); ?>"><div class="social tumb"></div></a><?php }?>
                <?php if($NHP_Options->get('dribble')!=''){?><a href="<?php $NHP_Options->show('dribble'); ?>"><div class="social dribble"></div></a><?php }?>
                <?php if($NHP_Options->get('rss')!=''){?><a href="<?php echo home_url().'/rss'//$NHP_Options->show('rss'); ?>"><div class="social rss"></div></a><?php }?>
                <?php if($NHP_Options->get('behance')!=''){?><a href="<?php $NHP_Options->show('behance'); ?>"><div class="social behance"></div></a><?php }?>
                <?php if($NHP_Options->get('google')!=''){?><a href="<?php $NHP_Options->show('google'); ?>"><div class="social google"></div></a><?php }?>
                <?php if($NHP_Options->get('instagram')!=''){?><a href="<?php $NHP_Options->show('instagram'); ?>"><div class="social instagram"></div></a><?php }?>
          </div> 
        </div>
      </div>
    </div>
    <li id="li-poliAntispam"><a href="#" id="poliAntispam">Política Anti-Spam</a></li>
  </footer>
      
  <div class="wrapper_copyright"> 
    <div class="container" id="nimtm5">
      <p class="copy_left">© <?php echo date('Y'); ?> <span class="white">V2contact</span>. Todos los derechos reservados. </p>
      <!--<div class="icones">
      <p class="copy_right"><span class="social">We are social:</span></p>
          <?php /*if($NHP_Options->get('tumblr')!=''){?><a href="<?php $NHP_Options->show('tumblr'); ?>"><div class="social tumb"></div></a><?php }?>
          <?php if($NHP_Options->get('dribble')!=''){?><a href="<?php $NHP_Options->show('dribble'); ?>"><div class="social dribble"></div></a><?php }?>
          <?php if($NHP_Options->get('rss')!=''){?><a href="<?php echo home_url().'/rss'//$NHP_Options->show('rss'); ?>"><div class="social rss"></div></a><?php }?>
          <?php if($NHP_Options->get('behance')!=''){?><a href="<?php $NHP_Options->show('behance'); ?>"><div class="social behance"></div></a><?php }?>
          <?php if($NHP_Options->get('google')!=''){?><a href="<?php $NHP_Options->show('google'); ?>"><div class="social google"></div></a><?php }?>
          <?php if($NHP_Options->get('instagram')!=''){?><a href="<?php $NHP_Options->show('instagram'); ?>"><div class="social instagram"></div></a><?php }*/?>
      </div> -->         
    </div>
  </div>                  
</div>

    <!-- //END page home(start al header.php) -->
    </div>

<?php
  /* Always have wp_footer() just before the closing </body>
   * tag of your theme, or you will break many plugins, which
   * generally use this hook to reference JavaScript files.
   */

  wp_footer();
?>
<script type="text/javascript">
  jQuery('ul.navegation li').eq(5).addClass('current-menu-item');
  jQuery('#pais').change(paises);
  function paises () {
      var $this = jQuery(this), data = 'do='+$this.val();//, tipoPais = $this.val();
      console.log('Cargando...');    
      jQuery.ajax({
          url: 'https://service.v2contact.com/include/ajax/ajax.paises.php',
          dataType: 'json',
          data: data,            
          success: function(rec)
           {
              if(rec.load){
                  //jQuery('.titol span').eq(0).text(tipoPais);
                  jQuery('#precios_v2c').html(rec.data);
                  console.log(rec.success_message);
              }else {
                  alert(rec.error_message);
              }
           }
      });
  }  

</script>

<section class="content">
  <div class="container_12">
    <div id="open-popup-politicas" class="simplemodal-data">
    <div id="popup" style="display: none;">
        <div class="content-popup">
            <div class="close"><a href="#" id="close"><img src="http://www.v2contact.com/imagenes/close.png"/></a></div>
            <div id="divContenido">
              <div class="titulov2c"><h2>Políticas de Privacidad</h2></div>
                <p>
                  En V2Contact®, la privacidad es un tema relevante. Nosotros estamos dedicados a establecer una relación de confianza con nuestros clientes y usuarios basado en el respeto de la identidad de las personas y su información.
                </p>
                <h4>Recopilación y uso de la información de nuestro sitio Web</h4>
                <p>
                  La información que recogemos de nuestro sitio Web, de nuestros clientes y de cualquier persona es usada para que pueda acceder a cualquiera de nuestras soluciones o comunicaciones. Esta información no será usada para ningún propósito como el de tipo de venta, uso o renta a terceros; para ningún fin en particular, sin la debida autorización correspondiente.
                </p>
                <p>
                  También es usada, en el caso que se genere interés por la comercialización de una de nuestras soluciones, con el fin de seleccionar nuestros prospectos para poder ser contactados por uno de nuestros representantes.
                </p>
                <p>
                  La dirección de email que es requerida en nuestro sitio web, y cualquier otra información solicitada, es usada para enviarle información que sólo usted ha solicitado. Nuestra empresa cree y trabaja para generar marketing de permiso, y solamente nos comunicamos con clientes que han dado su permiso para nosotros poder comunicarles.
                </p>
                <p>
                  Todos los emails, que podamos enviarles, tienen incluido la opción de interrumpir su subscripción cuando lo desee (opt-out), lo que genera que no se le enviará ningún tipo de comunicado de nuestra empresa a futuro.
                </p>
                <p>
                  Si mantenemos registro de las acciones y movimientos que se hacen en nuestro sitio Web, recopilamos información de las páginas vistas, click que se realicen, obtención de información disponible en la pagina, dirección IP y tipo de browser. Esto nos permite poder tener una página mejor costumizadas, que genere valor entendiendo el interés de navegación de los usuarios, ayuda en línea vía Chat y soporte técnico.
                </p>
                <p>
                  Por último, enviamos a todos los que nos han entregado su información, un newsletter por email con noticias, updates, nuevas características de nuestras soluciones y cualquier noticia relevante respecto a lo que hacemos y comercializamos, con ningún otro fin que el descrito.
                </p>
                <h4>Uso de información de nuestros clientes</h4>
                <p>
                  Si usted es un cliente de cualquiera de nuestras soluciones (o bien trabaja prestando servicios a través de nuestras soluciones), toda la información recopilada de sus lista de clientes y cualquier otra información es usada con la más absoluta privacidad dejándose aclarada en su uso y forma, a través de un contrato de confidencialidad.
                </p>
                <h4>Cookies</h4>
                <p>
                  Una cookie es un pequeño archivo de texto que es transferido a su computador por un servidor Web. Generalmente son usadas para mantener una autentificación del usuario, llevar un registro de navegación y mantener información específica de los usuarios. Cuando usted visita nuestro sitio web, abre un email o solicita algo, es probable que le enviemos una cookie.
                </p>
                <p>
                  El uso de nuestras cookies tiene como único objetivo conocer su permanencia y forma de navegación en nuestro site con la finalidad de mejorar nuestra página y valor de información, además de su experiencia con nosotros. Estas cookies no están linkeadas a ninguna dirección que no sea la nuestra y usted tiene el poder de aceptar o, bien, declinar el uso en su navegador de Internet. Para mayor información de cómo manejar las cookies en su navegador de Internet, entre al sitio www.aboutcookies.org
                </p>
                <h4>Información usada por terceros</h4>
                <p>
                  V2Contact® es una empresa que ofrece soluciones online, de forma on demand, las cuales son comercializadas usualmente a través de Resellers. Para eso, traspasamos nuestra política de privacidad a nuestros Resellers, estando así alineados tanto ellos como nosotros de establecer una relación de confianza con nuestros clientes y usuarios, basado en el respeto de la identidad de las personas y su información. Cada Reseller es requerido a firmar bajo un contrato a cumplir con la confidencialidad de los datos, para un mejor resguardo de nuestra política.
                </p>
                <h4>Seguridad</h4>
                <p>
                  V2Contact® toma la seguridad como clave dentro de las soluciones que proveemos. Por eso toma una responsabilidad proactiva para proteger esta información de manera eficaz y eficiente. V2Contact® cuenta con medidas de seguridad que protegen la perdida, mal uso o alteración de la información que está de nuestro control.
                </p>
                <div style="float:left; width:100%; margin-top: 25px;">
                  <iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FV2Contact&amp;width&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;share=true&amp;height=80&amp;appId=102699406494946" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:80px;" allowTransparency="true"></iframe>
                </div>
            </div>
        </div>
    </div>
    <div id="popupAntispam" style="display: none;">
        <div class="content-popup">
            <div class="close"><a href="#" id="close"><img src="http://www.v2contact.com/imagenes/close.png"/></a></div>
            <div id="divContenido">
              <div class="titulov2c"><h2>Política Anti-Spam</h2></div>
                <p>
                  V2Contact prohibe cualquier intento de uso de la plataforma para el envío de mensajes masivos no solicitados (vulgarmente conocido como spam).
                </p>
                <p>
                  V2Contact pone en práctica comprobaciones y controles activos de todas las actividades relacionadas con el envío de spam a través de la plataforma V2Contact, incluido un análisis automático de las bases de datos de contacto de los clientes y de los mensajes que estos envían a esa base de datos a través de V2Contact.
                </p>
                <p>
                  Si V2Contact sospecha que la cuenta de un cliente está asociada, de forma directa o indirecta, al envío de spam, esta cuenta sería suspendida inmediatamente sin previo aviso y sin derecho de restitución. V2Contact aplica, también, las medidas civiles, criminales y administrativas previstas por la ley. En el caso de tener conocimiento de que cualquier cliente de V2Contact violara esta política, por favor, infórmenos inmediatamente.
                </p>
                <h4>Prevención y tratamiento del spam</h4>
                <p>
                  Al inscribirse:<br>
                  Al aceptar esta Política Anti-spam, el cliente de V2Contact asume que su método de inscripción de contactos le obliga a poseer un registro previo, voluntario y consentido de los contactos y indicar claramente el uso que se le dará a los datos de contacto, además del tipo de comunicaciones que el contacto recibirá.
                </p>
                <h4> En el momento de la eliminación:</h4>
                <p>
                  El cliente de V2Contact acepta que en cada mensaje enviado a través de V2Contact, se incluya un botón de eliminación (a través del cual, el contacto puede eliminarse automáticamente de la base de datos del cliente) de  los datos de contacto del cliente, ya sea su contacto telefónico o su domicilio (mediante los cuales, el contacto puede solicitar una eliminación manual). En el caso de haber recibido un mensaje vía V2Contact y no haya pedido efectuar la eliminación o pretenda eliminar sus datos de contacto de todas las bases de datos de clientes de V2Contact, por favor, hable con nosotros. También puede contactarnos por teléfono o escribiendo a:
                </p>
                <p>
                  Calle 2 de Mayo 516 Mezanine Interior 12 Miraflores <br>
                  Lima Perú <br>
                  Tel: (+51) 1707-3501
                </p>
                <div style="float:left; width:100%; margin-top: 25px;">
                  <iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FV2Contact&amp;width&amp;layout=standard&amp;action=like&amp;show_faces=true&amp;share=true&amp;height=80&amp;appId=102699406494946" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:80px;" allowTransparency="true"></iframe>
                </div>
            </div>
        </div>
    </div>
    <div id="popup-overlay" class="popup-overlay"></div>
    </div>
  </div>
</section>

<script type="text/javascript">
jQuery(document).ready(function(){
  jQuery('#poliPrivacidad').click(function(){
    jQuery('#popup').fadeIn('slow');
    jQuery('.popup-overlay').fadeIn('slow');
    jQuery('.popup-overlay').css('height','100%');
    document.getElementById('cabeceraV2C').focus();
    jQuery('.wrapper_header').css({'background':'#777777','opacity':'0.7','z-index':'999'});
    return false;
  });
  
  jQuery('#poliAntispam').click(function(){
    jQuery('#popupAntispam').fadeIn('slow');
    jQuery('.popup-overlay').fadeIn('slow');
    jQuery('.popup-overlay').css('height','100%');
    jQuery('.wrapper_header').css({'background':'#777777','opacity':'0.7','z-index':'999'});
    return false;
  });

  jQuery('#close, #popup-overlay').click(function(){
    jQuery('#popup').fadeOut(600);
    jQuery('#popup').fadeOut('slow');
    jQuery('#popupAntispam').fadeOut(600);
    jQuery('#popupAntispam').fadeOut('slow');
    jQuery('.popup-overlay').fadeOut('slow');
    jQuery('.wrapper_header').css({'background':'#FFFFFF','opacity':'1'});
    return false;
  });

  //jQuery("body:contains('Paste your AdWords Remarketing code here')").css({'color':'#212121','background':'url(http://www.v2contact.com/wp-content/themes/zenite/css/img/bg_piebottom.jpg)'})
  //jQuery("body:contains('Paste your AdWords Remarketing code here')").css({'color':'#212121','background':'#00FF00'})
  jQuery('ul.navegation li>a').eq(5).css({'background':'#66981E','font-family':'Open Sans light V2C'});

  jQuery('#subfooter1 article>div.title').hide();
  jQuery('#subfooter1 article>div.separador').hide();
  jQuery('#subfooter1 ul').css({'float':'left','padding-left':'27px'});
  jQuery('#li-poliAntispam').appendTo( jQuery('#menu-menu-sub-left') );

  //jQuery('.bg-white').css('background','#00FF00');

});
</script>

</body>
</html>