
<form class="searchform" method="get" action="<?php bloginfo('home'); ?>/"> <input type="text" value="Search: type and hit enter" onfocus="if (this.value == 'Search: type and hit enter') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search: type and hit enter';}" size="18" maxlength="50" name="s" class="s" /> </form> 
