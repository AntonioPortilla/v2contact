Lead Image Setup:
(Featured Image on Homepage)

In the custom field area, enter the Name as "screen" and the 
Value as the "url" of the image (with 500px x 300px resolution).