<style type="text/css">
#v2c_apiform>form>div
{margin-top: 6px;
overflow: hidden;}
#v2c_apiform>form>div>label
{float: left;
cursor: pointer;
text-align: right;
width: 100px;
margin: 3px 5px 0 0;}
#v2c_apiform>form>div>input[type="submit"]{	
	float: right;
	border: none;
	background: #18D020;
    color: #FFFFFF;
    font-family: 'font-centros';
    font-size: 16pt;
    height: 36px;
    padding: 0 20px;
    text-align: center;
    text-decoration: none;
    width: auto;
    margin: 20px 30px 0px 0px; 
}
#v2c_apiform>form>div>input
{margin: 0px;
border: 1px solid #DDD;
background-color: #FFFFFF;}
</style>
<div id="sidebar">
<?php
global $options;
foreach ($options as $value) {
if (get_settings( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_settings( $value['id'] ); }
}
?>
<!-- featured news -->
<?php /*if ($pov_disfeat == "true") { } else { ?> 	
<div id="featured">			
<!-- <h2>Featured</h2> -->	
			
			<?php 
	$highcat = get_option('pov_story_category'); 
	$highcount = get_option('pov_story_count');
	
	$my_query = new WP_Query('category_name= '. $highcat .'&showposts='.$highcount.'');
while ($my_query->have_posts()) : $my_query->the_post();$do_not_duplicate = $post->ID;
?>

<div class="fblock">
<?php if ($pov_disthumb == "true") { } else { ?>
<a href="<?php the_permalink(); ?>"><?php dp_attachment_image($post->ID, 'thumbnail', 'alt="' . $post->post_title . '"'); ?></a>
<?php } ?>

<h3><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>

<p><?php echo pov_excerpt( get_the_excerpt(), '100'); ?></p>

</div>
<?php endwhile; ?>

</div>
<?php } */?>
		
<!-- end featured news -->
<ul style="padding-top:0px;">
	<li><h2>Suscribete ahora 2014</h2>			
		<div class="suscribete">			

		</div>

	</li>
	<li><h2>Sponsor</h2>			
		<div class="sponsor">
			<a href="http://www.centrosvirtuales.com" target="_blank"><img src="http://www.centrosvirtuales.com/banners/300X250.gif"  /></a>
		</div>
	</li>

	<li><h2>Siguenos en facebook</h2>			
		<div class="facebook">
			<iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Fpages%2FCentros-Virtuales-Alquiler-de-Oficinas-Para-Profesionales-y-Pymes%2F289226944430912&amp;width=292&amp;height=590&amp;colorscheme=light&amp;show_faces=true&amp;border_color&amp;stream=true&amp;header=false&amp;appId=286173234780934" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:292px; height:590px;" allowTransparency="true"></iframe>
		</div>
	</li>
<!--
<ul>
<?php /*if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar") ) : ?>

<li><h2>Publicaciones Recientes</h2></li>
			
<?php wp_get_archives('title_li=&type=postbypost&limit=5'); */?>
</ul> -->


	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar") ) : ?>

	<li><h2>Publicaciones Recientes</h2>
				
		<ul> 
			<li><?php wp_get_archives('title_li=&type=postbypost&limit=10'); ?></li>
		</ul>
	</li>
	<!--<li><h2>Archivos</h2>
		<ul>
			<li><?php //wp_get_archives('type=monthly'); ?></li>
		</ul>
	</li>-->

	<?php endif; ?>		
</ul>

</div>

