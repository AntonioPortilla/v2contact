<div id="menu">
	<ul id="secnav">
		<li>
			<a href="<?php echo home_url(); ?>">Inicio</a>
		</li>
		<li>
			<a href="<?php echo home_url(); ?>/precios/">Precios</a>
		</li>
		<li>
			<a href="<?php echo home_url(); ?>/servicios/">Servicios</a>
		</li>
		<li>
			<a href="<?php echo home_url(); ?>/contacto/">Contacto</a>
		</li>
		<li>
			<a href="http://www.centrosvirtuales.com/sistema/" class="mylogin">Login</a>
		</li>
	</ul>
</div>
<div style="clear: both;"></div>