



<form class="searchformhead" method="get" action="<?php bloginfo('url'); ?>">
	<p class="coco"><input type="text" name="s" class="s" size="30" value="Search" onfocus="if (this.value = '') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Search...';}" /><input type="submit" class="searchSubmit" value="" /></p>
</form>